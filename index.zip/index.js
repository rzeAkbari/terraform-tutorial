exports.helloWorld = (req, res) => {
    let name = process.env.name;
    let message = `Hello ${name}`;
    res.status(200).send(message);
};